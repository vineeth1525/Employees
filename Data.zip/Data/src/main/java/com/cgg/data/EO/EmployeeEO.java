package com.cgg.data.EO;

public class EmployeeEO {

}
