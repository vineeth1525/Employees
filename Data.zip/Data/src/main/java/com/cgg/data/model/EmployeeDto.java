package com.cgg.data.model;

import lombok.Data;

@Data
public class EmployeeDto {
private String employeeName;
private String dept;
private long salary;
private int id;

}
