package com.cgg.data.BO;

public class EmployeeBO {

}
