package com.cgg.data.utils;

public class CommonConstants {
	
//	public static String 

}
