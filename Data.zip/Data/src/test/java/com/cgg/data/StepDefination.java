package com.cgg.data;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import com.cgg.data.model.Employee;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefination {

	
	@When("employee logins")
	public void employee_logins() {
		System.out.println("employee logged in succefully");
	}

	

	


	@When("sending my details name <employeeName> id <Id> dept <dept> salary<salary>")
	public void sending_my_details_name_employee_name_id_id_dept_dept_salary_salary() {
		
		Employee employee = new Employee("ram", 5,"eee",1000l);
		assertEquals(employee.getEmployeeName(), "ram");
	}
	

		@Then("employee details are printed")
		public void employee_details_are_printed() {
			List<Employee> emp = new ArrayList<>();
			Employee employee1 = new Employee("elon", 5,"eee",1000l);
			Employee employee2 = new Employee("musk", 5,"eee",1000l);
		emp.add(employee1);
		emp.add(employee2);
		assertEquals(emp.size(), 2);
		}
}//restauserd serinity
